#!

"""DECnet config

"""

from .executor import Executor

executor = Executor (1 * 1024 + 44, "PYTEST")
