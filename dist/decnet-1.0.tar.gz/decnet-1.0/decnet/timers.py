#!/usr/bin/env python3

"""Timer support for DECnet

This implements the timer wheel mechanism, with callbacks on expiration.
"""

import abc
import threading

class StopThread (threading.Thread):
    """A thread with stop method.
    """
    def __init__ (self):
        super ().__init__ ()
        self.stopnow = False

    def stop (self, wait = False):
        """Stop the thread associated with this connection.  The actual
        handling of "stopnow" needs to go into the class that uses this.

        If "wait" is True, wait for the thread to exit.
        """
        if not self.stopnow and self.isAlive ():
            self.stopnow = True
            if wait:
                self.join ()

class Cque (object):
    """Base class for objects that can be put on a circular queue.
    Instances of this class will also serve as list heads.
    """
    def __init__ (self):
        self.next = self.prev = self

    reset = __init__
    
    def add (self, item):
        """Insert "item" as the successor of this object, i.e., first
        on the list if this is the list head.
        """
        item.prev = self
        item.next = self.next
        self.next.prev = item
        self.next = item

    def remove (self):
        """Remove this item from whatever circular queue it is on.
        To avoid trouble, we also link this item to itself, so accidental
        repeat calls to remove won't corrupt the queue.
        """
        self.next.prev = self.prev
        self.prev.next = self.next
        self.reset ()

    def __bool__ (self):
        """Return True if the queue is not empty.
        """
        return self.next != self
    
class Timer (Cque):
    """Abstract base class for an object that can be put on the
    TimerWheel, i.e., acts as a timer.
    """
    @abstractmethod
    def timeout (self):
        """This method is called if the timer expires.
        """
        pass

class CallbackTimer (Timer):
    """A simple timer that does a call to a given function with
    a given argument on expiration.
    """
    def __init__ (self, fun, args):
        super ().__init__ ()
        self.fun = fun
        self.args = args

    def timeout (self):
        self.fun (self.args)
        
class TimerWheel (StopThread):
    """A timer wheel.
    """
    # We want to reuse these names for the timer API.
    _start = StopThread.start
    _stop = StopThread.stop
    
    def __init__ (self, tick, maxtime):
        """Define a wheel that ticks every "tick" seconds and has
        a max tick count of "maxtime".
        """
        super ().__init__ ()
        self.wheel = [ Cque () for i in range (maxtime) ]
        self.pos = 0
        self.maxtime = maxtime
        self.tick = tick
        self.lock = threading.Lock ()
        self._start ()

    def start (self, item, timeout):
        """Start timer running for "item", it will time out in "timeout"
        seconds.
        """
        ticks = timeout // self.tick
        if ticks > self.maxtime:
            raise OverflowError ("Timeout %d too large" % timeout)
        if not isinstance (item, Timer):
            raise TypeError ("Timer item is not of Timer type")
        pos = (self.pos + ticks) % self.maxtime
        self.lock.acquire ()
        self.wheel[pos].insert (item)
        self.lock.release ()
        
    def run (self):
        """Tick handler.
        """
        while not self.stopnow:
            time.sleep (self.tick)
            pos = self.pos = (self.pos + 1) % self.maxtime
            qh = self.wheel[pos]
            self.lock.acquire ()
            if qh:
                qhc = copy.copy (qh)
                qh.reset ()
                self.lock.release ()
                while True:
                    item = qhc.next
                    if item == qhc:
                        break
                    item.remove ()
                    item.timeout ()

    def shutdown (self):
        self._stop (True)

    def stop (self, item):
        """Stop the timer for "item".
        """
        self.lock.acquire ()
        item.remove ()
        self.lock.release ()

    
