#!/usr/bin/env python3

"""DECnet routing point to point datalink dependent sublayer

"""

from .packet import *
from .config import executor

class ShortData (Packet):
    layout = (( "bm", "sfpd", 0, 2 ),
              ( "bm", "rqr", 3, 1 ),
              ( "bm", "rts", 4, 1 ),
              ( "bm", "v", 6, 1 ),
              ( "b", "dstnode", 2 ),
              ( "b", "srcnode", 2 ),
              ( "bm", "visit", 0, 6 ))
    
class PtpPInit (Packet):
    layout = (( "bm", "control", 0, 1 ),
              ( "bm", "type", 1, 3 ),
              ( "b", "srcnode", 2 ),
              ( "bm", "ntype", 0, 2 ),
              ( "bm", "verif", 2, 1 ),
              ( "bm", "blo", 3, 1 ),
              ( "b", "blksize", 2 ),
              ( "b", "tiver", 3 ),
              ( "b", "timer", 2 ),
              ( "i", "reserved", 64 ))

class PtpVerify (Packet):
    layout = (( "bm", "control", 0, 1 ),
              ( "bm", "type", 1, 3 ),
              ( "b", "srcnode", 2 ),
              ( "i", "fcnval", 64 ))

class PtpHello (Packet):
    layout = (( "bm", "control", 0, 1 ),
              ( "bm", "type", 1, 3 ),
              ( "b", "srcnode", 2 ),
              ( "i", "testdata", 128 ))

class PtpCircuit (object):
    """A point to point circuit, i.e., the datalink dependent
    routing sublayer instance for a non-Ethernet type circuit.

    Arguments are "id" (circuit index), "name" (user visible name)
    and "datalink" (the datalink layer object for this circuit).
    """
    def __init__ (self, id, name, datalink):
        self.id = id
        self.name = name
        self.hellotimer = CallbackTimer (self.hellotimeout, self)
        self.listentimer = CallbackTimer (self.listentimeout, self)
        self.hellotime = 15
        self.listentime = self.hellotime * 3
        self.datalink = datalink
        i = self.initmsg = PtpInit ()
        i.control = 1
        i.type = 0
        i.srcnode = executor.nodeid
        i.ntype = executor.type
        i.verif = 0
        i.blksize = 576
        h = self.hellomsg = PtpHello ()
        h.control = 1
        h.type = 2
        h.srcnode = executor.nodeid
        h.testdata = b'\252' * 10
        
    def hellotimeout (self):
        # Send a hello message
        self.datalink.send (self.hellomsg)
        # Restart the timer
        executor.timers.start (self.hellotimer, self.hellotime)
        
    def listentimeout (self):
        executor.circuit_down (id)
        
