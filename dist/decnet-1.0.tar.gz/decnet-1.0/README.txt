This is an implementation of the DECnet Phase IV protocols as 
Python modules (including DECnet Phase III interoperability).

Right now this is very very incomplete.
